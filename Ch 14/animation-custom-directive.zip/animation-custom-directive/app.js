angular.module('animationDemo', ['ngAnimate']).directive('shakeDiv', function($animate, $timeout) {
  return {
    link: function(scope, elem, attrs) {
      scope.generateRandom = function() {
        scope.randomValue = Math.random().toFixed(2);
        if (scope.randomValue > 0.5) {
          $animate.addClass(elem.find('.my-animation-class'), 'shake');
          $timeout(function() {
            $animate.removeClass(elem.find('.my-animation-class'), 'shake');
          }, 1000);
        }
      }
    },
    template: '<input type="button" ng-click="generateRandom()" value="Generate Random Value"/><h2 class="my-animation-class">{{randomValue}}</h2>'
  }
});