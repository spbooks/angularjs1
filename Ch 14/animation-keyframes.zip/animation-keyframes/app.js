angular.module('animationDemo', ['ngAnimate']);
