angular.module('animationDemo', ['ngAnimate']);

angular.module('animationDemo').animation('.my-animation-class',function(){
  return {
    addClass : function(elem, className, done) {
      if(className==='growing-div'){
        elem.animate({width: '200px',height:'200px',duration: 1000, queue: true}, done);
      }
    },
    removeClass : function(elem, className, done) {
      if(className==='growing-div'){
        elem.animate({width: '100px',height:'100px',duration: 1000, queue: true},done);
      }
    }
    
  }
});
