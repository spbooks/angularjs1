angular.module('animationDemo', ['ngAnimate']).animation('.my-animation-class',function(){
  return {
    enter: function(elem,done){
      
      elem.css({
        background:'green',
        opacity:0
      });

      elem.animate({
        backgroundColor:'white',
        opacity:1
      }, done);
      
    },
    leave:function(elem,done){
      elem.css({
        opacity:1
      });

      elem.animate({
        opacity:0
      }, done);
    },
    addClass : function(element, className, done) {},
    removeClass : function(element, className, done) {}
    
  }
});
