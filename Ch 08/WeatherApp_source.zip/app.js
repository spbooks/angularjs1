angular.module('mainApp', []);

angular.module('mainApp').controller('WeatherController', function($scope, weatherService) {
  $scope.getWeather = function() {
    $scope.weatherDescription = "Fetching . . .";
    weatherService.getWeather($scope.city, $scope.country).success(function(data) {
      $scope.weatherDescription = data.weather[0].description;
    }).error(function() {
      $scope.weatherDescription = "Could not obtain data";
    });
  }
});

angular.module('mainApp').factory('weatherService', function($http) {
  return {
    getWeather: function(city, country) {
      var query = 'q=' + city + ',' + country;
      return $http.get('http://api.openweathermap.org/data/2.5/weather?' + query,{cache:true});
    }
  }
});